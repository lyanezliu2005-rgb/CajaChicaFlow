#!/bin/bash
# setup.sh — Script de instalación inicial de ExpenseFlow SaaS
set -e

echo "🚀 ExpenseFlow SaaS — Setup Inicial"
echo "====================================="

# 1. Verificar dependencias
echo "Verificando dependencias..."
command -v docker >/dev/null 2>&1 || { echo "❌ Docker no instalado"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1 || { echo "❌ Docker Compose no instalado"; exit 1; }
command -v openssl >/dev/null 2>&1 || { echo "❌ OpenSSL no instalado"; exit 1; }

echo "✅ Dependencias OK"

# 2. Copiar .env si no existe
if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ Archivo .env creado (edítalo con tus valores)"
fi

# 3. Generar claves JWT RS256
if [ ! -f ./backend/keys/private.pem ]; then
  echo "Generando claves JWT RS256..."
  mkdir -p ./backend/keys
  openssl genrsa -out ./backend/keys/private.pem 4096
  openssl rsa -in ./backend/keys/private.pem -pubout -out ./backend/keys/public.pem
  chmod 600 ./backend/keys/private.pem
  echo "✅ Claves JWT generadas en ./backend/keys/"
  echo ""
  echo "⚠️  Agrega estas claves al .env:"
  echo "JWT_PRIVATE_KEY contenido de private.pem (una línea, \\n como separador)"
  echo "JWT_PUBLIC_KEY contenido de public.pem (una línea, \\n como separador)"
fi

# 4. Generar secrets aleatorios
echo ""
echo "Secrets generados (cópialos a tu .env):"
echo "POSTGRES_PASSWORD=$(openssl rand -hex 24)"
echo "REDIS_PASSWORD=$(openssl rand -hex 24)"
echo "COOKIE_SECRET=$(openssl rand -hex 32)"
echo "ENCRYPTION_KEY=$(openssl rand -hex 32)"
echo ""

# 5. Construir e iniciar servicios
echo "Iniciando servicios Docker..."
docker compose up -d postgres redis minio

echo "Esperando que la base de datos esté lista..."
sleep 5

echo "Ejecutando migraciones..."
docker compose run --rm backend npm run db:migrate
docker compose run --rm backend npm run db:generate

echo "Iniciando todos los servicios..."
docker compose up -d

echo ""
echo "✅ ExpenseFlow SaaS iniciado correctamente!"
echo ""
echo "🌐 Frontend:    http://localhost:3000"
echo "🔌 Backend API: http://localhost:3001"
echo "💾 MinIO:       http://localhost:9001"
echo ""
echo "Para crear el primer Super Admin:"
echo "  docker compose exec backend node -e \"require('./dist/utils/create-super-admin')\""
