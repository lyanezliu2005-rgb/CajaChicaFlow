-- backend/prisma/tenant-schema.sql
-- Este SQL se ejecuta al crear cada nueva empresa (tenant)
-- Se reemplaza {SCHEMA} por el slug del tenant

-- Crear schema aislado
CREATE SCHEMA IF NOT EXISTS {SCHEMA};

-- Habilitar Row-Level Security en todas las tablas

-- ─── USUARIOS DEL TENANT ──────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.users (
  id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  name          TEXT NOT NULL,
  avatar_url    TEXT,
  phone         TEXT,
  department    TEXT,
  position      TEXT,
  
  -- Autenticación
  mfa_secret    TEXT,
  mfa_enabled   BOOLEAN DEFAULT false,
  last_login_at TIMESTAMPTZ,
  last_login_ip TEXT,
  login_attempts INT DEFAULT 0,
  locked_until  TIMESTAMPTZ,
  
  -- Estado
  is_active     BOOLEAN DEFAULT true,
  email_verified BOOLEAN DEFAULT false,
  verify_token  TEXT,
  reset_token   TEXT,
  reset_expires TIMESTAMPTZ,
  
  created_at    TIMESTAMPTZ DEFAULT now(),
  updated_at    TIMESTAMPTZ DEFAULT now(),
  deleted_at    TIMESTAMPTZ
);

CREATE INDEX {SCHEMA}_users_email ON {SCHEMA}.users(email);
CREATE INDEX {SCHEMA}_users_active ON {SCHEMA}.users(is_active) WHERE deleted_at IS NULL;

-- ─── ROLES ────────────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.roles (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  is_system   BOOLEAN DEFAULT false,  -- roles del sistema no se eliminan
  permissions JSONB DEFAULT '[]',
  created_at  TIMESTAMPTZ DEFAULT now(),
  updated_at  TIMESTAMPTZ DEFAULT now()
);

-- Insertar roles base al crear el tenant
INSERT INTO {SCHEMA}.roles (name, slug, description, is_system, permissions) VALUES
  ('Super Admin Empresa', 'company_admin', 'Administrador de la empresa', true, 
   '["*"]'),
  ('Gerente / Aprobador', 'manager', 'Aprueba solicitudes de su área', true,
   '["expenses.read","expenses.approve","reports.read.own"]'),
  ('Colaborador', 'employee', 'Crea y sube solicitudes', true,
   '["expenses.create","expenses.read.own","files.upload"]'),
  ('Finanzas', 'finance', 'Revisión contable y exportación ERP', true,
   '["expenses.read","expenses.approve","reports.read","erp.export"]'),
  ('Auditor', 'auditor', 'Solo lectura y trazabilidad', true,
   '["expenses.read","reports.read","audit.read"]');

-- ─── USER_ROLES ───────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.user_roles (
  user_id    TEXT REFERENCES {SCHEMA}.users(id) ON DELETE CASCADE,
  role_id    TEXT REFERENCES {SCHEMA}.roles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, role_id)
);

-- ─── DEPARTAMENTOS ────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.departments (
  id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name       TEXT NOT NULL,
  code       TEXT,
  manager_id TEXT REFERENCES {SCHEMA}.users(id),
  budget     NUMERIC(15,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── COST CENTERS ────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.cost_centers (
  id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code       TEXT NOT NULL UNIQUE,
  name       TEXT NOT NULL,
  budget     NUMERIC(15,2) DEFAULT 0,
  dept_id    TEXT REFERENCES {SCHEMA}.departments(id),
  is_active  BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ─── WORKFLOW TEMPLATES ───────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.workflow_templates (
  id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  name         TEXT NOT NULL,
  description  TEXT,
  expense_type TEXT[] DEFAULT '{"travel","petty_cash"}',  -- a qué tipos aplica
  is_active    BOOLEAN DEFAULT true,
  created_at   TIMESTAMPTZ DEFAULT now(),
  updated_at   TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE {SCHEMA}.workflow_stages (
  id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  workflow_id         TEXT REFERENCES {SCHEMA}.workflow_templates(id) ON DELETE CASCADE,
  stage_order         INT NOT NULL,
  name                TEXT NOT NULL,
  approver_role_id    TEXT REFERENCES {SCHEMA}.roles(id),
  approver_user_id    TEXT REFERENCES {SCHEMA}.users(id),  -- aprobador específico opcional
  approval_type       TEXT DEFAULT 'any',  -- 'any' | 'all' (para aprobación paralela)
  sla_hours           INT DEFAULT 48,
  escalate_to_role_id TEXT REFERENCES {SCHEMA}.roles(id),
  max_amount          NUMERIC(15,2),  -- límite para este rol (NULL = sin límite)
  min_amount          NUMERIC(15,2),  -- mínimo para activar esta etapa
  is_optional         BOOLEAN DEFAULT false,
  notify_on_start     BOOLEAN DEFAULT true,
  created_at          TIMESTAMPTZ DEFAULT now()
);

-- Insertar workflow default al crear el tenant
INSERT INTO {SCHEMA}.workflow_templates (id, name, description) VALUES
  ('wf_default', 'Flujo Estándar', 'Flujo de aprobación por defecto');

INSERT INTO {SCHEMA}.workflow_stages (workflow_id, stage_order, name, approver_role_id, sla_hours) VALUES
  ('wf_default', 1, 'Jefe Directo',    (SELECT id FROM {SCHEMA}.roles WHERE slug='manager'), 24),
  ('wf_default', 2, 'Revisión Finanzas',(SELECT id FROM {SCHEMA}.roles WHERE slug='finance'), 48),
  ('wf_default', 3, 'Gerencia',        (SELECT id FROM {SCHEMA}.roles WHERE slug='company_admin'), 72);

-- ─── EXPENSE REQUESTS ────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.expense_requests (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  code            TEXT NOT NULL UNIQUE,  -- EF-2026-001234
  requester_id    TEXT NOT NULL REFERENCES {SCHEMA}.users(id),
  dept_id         TEXT REFERENCES {SCHEMA}.departments(id),
  cost_center_id  TEXT REFERENCES {SCHEMA}.cost_centers(id),
  workflow_id     TEXT REFERENCES {SCHEMA}.workflow_templates(id),
  
  -- Tipo y descripción
  expense_type    TEXT NOT NULL CHECK (expense_type IN ('travel','petty_cash','reimbursement','advance')),
  title           TEXT NOT NULL,
  description     TEXT,
  justification   TEXT,
  
  -- Montos
  currency        TEXT DEFAULT 'CLP',
  amount_requested NUMERIC(15,2) NOT NULL,
  amount_approved  NUMERIC(15,2),
  
  -- Viaje (si aplica)
  travel_origin    TEXT,
  travel_destination TEXT,
  travel_start     DATE,
  travel_end       DATE,
  
  -- Estado del workflow
  status           TEXT DEFAULT 'draft' CHECK (status IN (
    'draft','pending','in_review','approved','rejected','cancelled','paid','exported'
  )),
  current_stage    INT DEFAULT 1,
  
  -- Integración ERP
  erp_exported_at  TIMESTAMPTZ,
  erp_reference    TEXT,
  erp_status       TEXT,
  
  submitted_at     TIMESTAMPTZ,
  completed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT now(),
  updated_at       TIMESTAMPTZ DEFAULT now(),
  deleted_at       TIMESTAMPTZ
);

CREATE INDEX {SCHEMA}_expenses_requester ON {SCHEMA}.expense_requests(requester_id);
CREATE INDEX {SCHEMA}_expenses_status ON {SCHEMA}.expense_requests(status);
CREATE INDEX {SCHEMA}_expenses_created ON {SCHEMA}.expense_requests(created_at);

-- Secuencia para código autoincremental
CREATE SEQUENCE {SCHEMA}.expense_code_seq START 1;

-- ─── APPROVAL STEPS (historial del workflow) ─────────────────────────────────

CREATE TABLE {SCHEMA}.approval_steps (
  id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  expense_id     TEXT NOT NULL REFERENCES {SCHEMA}.expense_requests(id) ON DELETE CASCADE,
  stage_id       TEXT REFERENCES {SCHEMA}.workflow_stages(id),
  stage_order    INT NOT NULL,
  stage_name     TEXT NOT NULL,
  
  approver_id    TEXT REFERENCES {SCHEMA}.users(id),  -- quién realmente aprobó
  
  action         TEXT CHECK (action IN ('pending','approved','rejected','returned','delegated','auto_escalated')),
  comment        TEXT,
  
  -- Trazabilidad
  ip             TEXT,
  user_agent     TEXT,
  
  due_at         TIMESTAMPTZ,
  acted_at       TIMESTAMPTZ,
  created_at     TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX {SCHEMA}_approval_steps_expense ON {SCHEMA}.approval_steps(expense_id);

-- ─── EXPENSE ITEMS (líneas de gasto) ─────────────────────────────────────────

CREATE TABLE {SCHEMA}.expense_items (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  expense_id  TEXT NOT NULL REFERENCES {SCHEMA}.expense_requests(id) ON DELETE CASCADE,
  category    TEXT NOT NULL,  -- 'flight','hotel','food','transport','material','other'
  description TEXT NOT NULL,
  amount      NUMERIC(15,2) NOT NULL,
  currency    TEXT DEFAULT 'CLP',
  expense_date DATE,
  vendor      TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
);

-- ─── ATTACHMENTS (boletas, facturas) ─────────────────────────────────────────

CREATE TABLE {SCHEMA}.attachments (
  id           TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  expense_id   TEXT NOT NULL REFERENCES {SCHEMA}.expense_requests(id) ON DELETE CASCADE,
  uploader_id  TEXT NOT NULL REFERENCES {SCHEMA}.users(id),
  
  filename     TEXT NOT NULL,       -- nombre original
  stored_name  TEXT NOT NULL,       -- nombre UUID en storage
  storage_path TEXT NOT NULL,       -- ruta completa en bucket
  mime_type    TEXT NOT NULL,
  size_bytes   INT NOT NULL,
  
  -- OCR / validación
  ocr_data     JSONB,               -- datos extraídos automáticamente
  is_valid     BOOLEAN,             -- validado por finanzas
  virus_scanned BOOLEAN DEFAULT false,
  
  created_at   TIMESTAMPTZ DEFAULT now()
);

-- ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.notifications (
  id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  user_id    TEXT NOT NULL REFERENCES {SCHEMA}.users(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  title      TEXT NOT NULL,
  body       TEXT,
  link       TEXT,
  read       BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX {SCHEMA}_notifications_user ON {SCHEMA}.notifications(user_id, read);

-- ─── REFRESH TOKENS ───────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.refresh_tokens (
  id         TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  user_id    TEXT NOT NULL REFERENCES {SCHEMA}.users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  user_agent TEXT,
  ip         TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX {SCHEMA}_refresh_tokens_user ON {SCHEMA}.refresh_tokens(user_id);

-- ─── AUDIT LOG DEL TENANT ─────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.audit_logs (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  user_id     TEXT,
  action      TEXT NOT NULL,
  resource    TEXT NOT NULL,
  resource_id TEXT,
  old_data    JSONB,
  new_data    JSONB,
  ip          TEXT,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX {SCHEMA}_audit_logs_user ON {SCHEMA}.audit_logs(user_id);
CREATE INDEX {SCHEMA}_audit_logs_created ON {SCHEMA}.audit_logs(created_at);

-- ─── ERP CONFIG ───────────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.erp_configs (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  erp_type    TEXT NOT NULL,  -- 'sap','oracle','dynamics','custom'
  name        TEXT NOT NULL,
  endpoint    TEXT,
  auth_type   TEXT DEFAULT 'bearer',  -- 'bearer','basic','oauth2','api_key'
  credentials BYTEA,  -- encriptado con AES-256-GCM
  headers     JSONB,
  payload_map JSONB,  -- mapeo de campos a estructura del ERP
  is_active   BOOLEAN DEFAULT false,
  last_sync_at TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT now(),
  updated_at  TIMESTAMPTZ DEFAULT now()
);

-- ─── COMPANY CONFIG ───────────────────────────────────────────────────────────

CREATE TABLE {SCHEMA}.company_config (
  key        TEXT PRIMARY KEY,
  value      JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now()
);

INSERT INTO {SCHEMA}.company_config VALUES
  ('expense_limits',   '{"petty_cash": 500000, "travel": 5000000, "advance": 2000000}'),
  ('notifications',    '{"email": true, "in_app": true, "slack": false}'),
  ('ocr_enabled',      'true'),
  ('auto_export_erp',  'false'),
  ('require_justification_above', '200000');

-- ─── ROW LEVEL SECURITY ───────────────────────────────────────────────────────

ALTER TABLE {SCHEMA}.expense_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE {SCHEMA}.attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE {SCHEMA}.notifications ENABLE ROW LEVEL SECURITY;

-- Grants para el usuario de la aplicación
GRANT USAGE ON SCHEMA {SCHEMA} TO expenseflow_app;
GRANT ALL ON ALL TABLES IN SCHEMA {SCHEMA} TO expenseflow_app;
GRANT ALL ON ALL SEQUENCES IN SCHEMA {SCHEMA} TO expenseflow_app;
