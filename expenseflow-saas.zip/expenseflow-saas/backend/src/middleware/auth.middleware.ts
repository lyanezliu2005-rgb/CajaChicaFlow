// backend/src/middleware/auth.middleware.ts
import { FastifyRequest, FastifyReply } from 'fastify'
import jwt from 'jsonwebtoken'
import { env } from '../config/env'
import { redisClient } from '../config/redis'
import { prisma } from '../config/database'

export interface JWTPayload {
  sub: string          // user ID
  type: 'super_admin' | 'tenant_user'
  tenantId?: string
  tenantSchema?: string
  roles: string[]
  permissions: string[]
  iat: number
  exp: number
  jti: string          // JWT ID para revocación
}

declare module 'fastify' {
  interface FastifyRequest {
    user: JWTPayload
    tenantSchema: string
  }
}

export function authMiddleware(requiredType: 'super_admin' | 'tenant_user') {
  return async function (request: FastifyRequest, reply: FastifyReply) {
    try {
      // 1. Extraer token del header Authorization
      const authHeader = request.headers.authorization
      if (!authHeader?.startsWith('Bearer ')) {
        return reply.status(401).send({
          statusCode: 401,
          error: 'Unauthorized',
          message: 'Token de acceso requerido',
        })
      }

      const token = authHeader.substring(7)

      // 2. Verificar firma RS256
      let payload: JWTPayload
      try {
        payload = jwt.verify(token, env.JWT_PUBLIC_KEY, {
          algorithms: ['RS256'],
        }) as JWTPayload
      } catch (jwtError: any) {
        const message = jwtError.name === 'TokenExpiredError'
          ? 'Token expirado. Refresca tu sesión.'
          : 'Token inválido'
        return reply.status(401).send({ statusCode: 401, error: 'Unauthorized', message })
      }

      // 3. Verificar que el token no esté en blacklist (revocado)
      const isBlacklisted = await redisClient.get(`blacklist:${payload.jti}`)
      if (isBlacklisted) {
        return reply.status(401).send({
          statusCode: 401,
          error: 'Unauthorized',
          message: 'Token revocado. Inicia sesión nuevamente.',
        })
      }

      // 4. Verificar tipo de usuario
      if (payload.type !== requiredType) {
        return reply.status(403).send({
          statusCode: 403,
          error: 'Forbidden',
          message: 'No tienes permisos para acceder a este recurso',
        })
      }

      // 5. Adjuntar payload al request
      request.user = payload

    } catch (error) {
      request.log.error({ err: error }, 'Error en autenticación')
      return reply.status(500).send({
        statusCode: 500,
        error: 'Internal Server Error',
        message: 'Error de autenticación',
      })
    }
  }
}

// Helper para verificar permisos granulares
export function requirePermission(permission: string) {
  return async function (request: FastifyRequest, reply: FastifyReply) {
    const { permissions } = request.user
    if (!permissions.includes('*') && !permissions.includes(permission)) {
      return reply.status(403).send({
        statusCode: 403,
        error: 'Forbidden',
        message: `Permiso requerido: ${permission}`,
      })
    }
  }
}

// Generar access token (15 min)
export function generateAccessToken(payload: Omit<JWTPayload, 'iat' | 'exp' | 'jti'>): string {
  const { v4: uuidv4 } = require('uuid')
  return jwt.sign(
    { ...payload, jti: uuidv4() },
    env.JWT_PRIVATE_KEY,
    { algorithm: 'RS256', expiresIn: env.JWT_ACCESS_EXPIRES }
  )
}

// Revocar token (añadir a blacklist hasta expiración)
export async function revokeToken(jti: string, expiresAt: number): Promise<void> {
  const ttl = Math.max(0, expiresAt - Math.floor(Date.now() / 1000))
  if (ttl > 0) {
    await redisClient.setex(`blacklist:${jti}`, ttl, '1')
  }
}
