// backend/src/middleware/tenant.middleware.ts
// CRÍTICO: Este middleware garantiza el aislamiento entre tenants

import { FastifyRequest, FastifyReply } from 'fastify'
import { redisClient } from '../config/redis'
import { prisma } from '../config/database'

const TENANT_CACHE_TTL = 300 // 5 minutos

interface CachedTenant {
  id: string
  slug: string
  schemaName: string
  status: string
  name: string
}

export async function tenantMiddleware(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  try {
    // Resolver tenant por múltiples métodos (en orden de prioridad):
    // 1. Header X-Tenant-ID (para apps móviles / API externa)
    // 2. Subdominio (acme.expenseflow.app)
    // 3. Path parameter /api/v1/t/:tenantSlug (si aplica)

    let tenantSlug: string | null = null

    // Método 1: Header explícito
    const headerTenantId = request.headers['x-tenant-id'] as string
    if (headerTenantId) {
      // Sanitizar: solo letras, números y guiones
      tenantSlug = headerTenantId.replace(/[^a-z0-9-]/gi, '').toLowerCase()
    }

    // Método 2: Subdominio
    if (!tenantSlug) {
      const host = request.headers.host || ''
      const subdomain = host.split('.')[0]
      const knownSubdomains = ['www', 'api', 'admin', 'app', 'localhost']
      if (subdomain && !knownSubdomains.includes(subdomain)) {
        tenantSlug = subdomain.toLowerCase()
      }
    }

    if (!tenantSlug) {
      return reply.status(400).send({
        statusCode: 400,
        error: 'Bad Request',
        message: 'Empresa no identificada. Incluye el header X-Tenant-ID.',
      })
    }

    // Buscar en cache Redis primero
    const cacheKey = `tenant:${tenantSlug}`
    const cached = await redisClient.get(cacheKey)

    let tenant: CachedTenant

    if (cached) {
      tenant = JSON.parse(cached)
    } else {
      // Consultar DB
      const dbTenant = await prisma.tenant.findUnique({
        where: { slug: tenantSlug, deletedAt: null },
        select: { id: true, slug: true, schemaName: true, status: true, name: true },
      })

      if (!dbTenant) {
        return reply.status(404).send({
          statusCode: 404,
          error: 'Not Found',
          message: 'Empresa no encontrada',
        })
      }

      tenant = dbTenant
      // Cachear resultado
      await redisClient.setex(cacheKey, TENANT_CACHE_TTL, JSON.stringify(tenant))
    }

    // Verificar estado
    if (tenant.status === 'SUSPENDED') {
      return reply.status(403).send({
        statusCode: 403,
        error: 'Forbidden',
        message: 'Esta empresa ha sido suspendida. Contacta a soporte.',
      })
    }

    if (tenant.status === 'CANCELLED') {
      return reply.status(403).send({
        statusCode: 403,
        error: 'Forbidden',
        message: 'Esta cuenta ha sido cancelada.',
      })
    }

    // CRÍTICO: Adjuntar schema al request para que todos los queries
    // usen el schema correcto del tenant
    request.tenantSchema = tenant.schemaName

    // También adjuntar tenantId al user cuando sea autenticado
    // (verificado después por authMiddleware)

  } catch (error) {
    request.log.error({ err: error }, 'Error en tenant middleware')
    return reply.status(500).send({
      statusCode: 500,
      error: 'Internal Server Error',
      message: 'Error al resolver la empresa',
    })
  }
}

// Invalidar cache de tenant (llamar cuando se modifique el tenant)
export async function invalidateTenantCache(slug: string): Promise<void> {
  await redisClient.del(`tenant:${slug}`)
}
