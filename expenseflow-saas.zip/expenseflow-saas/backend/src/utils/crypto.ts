// backend/src/utils/crypto.ts
// Encriptación AES-256-GCM para datos sensibles (credenciales ERP, etc.)

import { createCipheriv, createDecipheriv, randomBytes } from 'crypto'
import { env } from '../config/env'

const ALGORITHM = 'aes-256-gcm'
const IV_LENGTH = 16
const AUTH_TAG_LENGTH = 16
const KEY = Buffer.from(env.ENCRYPTION_KEY, 'hex') // 32 bytes

/**
 * Encripta un string con AES-256-GCM
 * Retorna: IV (hex) + AuthTag (hex) + CipherText (hex)
 */
export async function encrypt(plaintext: string): Promise<string> {
  const iv = randomBytes(IV_LENGTH)
  const cipher = createCipheriv(ALGORITHM, KEY, iv, { authTagLength: AUTH_TAG_LENGTH })

  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ])

  const authTag = cipher.getAuthTag()

  // Concatenar IV + AuthTag + CipherText en hex
  return iv.toString('hex') + authTag.toString('hex') + encrypted.toString('hex')
}

/**
 * Desencripta un string AES-256-GCM
 */
export async function decrypt(ciphertext: string): Promise<string> {
  const iv = Buffer.from(ciphertext.slice(0, IV_LENGTH * 2), 'hex')
  const authTag = Buffer.from(ciphertext.slice(IV_LENGTH * 2, (IV_LENGTH + AUTH_TAG_LENGTH) * 2), 'hex')
  const encrypted = Buffer.from(ciphertext.slice((IV_LENGTH + AUTH_TAG_LENGTH) * 2), 'hex')

  const decipher = createDecipheriv(ALGORITHM, KEY, iv, { authTagLength: AUTH_TAG_LENGTH })
  decipher.setAuthTag(authTag)

  return decipher.update(encrypted) + decipher.final('utf8')
}

/**
 * Hash HMAC-SHA256 para verificaciones (no para contraseñas - usar argon2 para eso)
 */
export function hmacSha256(data: string, secret: string): string {
  const { createHmac } = require('crypto')
  return createHmac('sha256', secret).update(data).digest('hex')
}

/**
 * Genera un token aleatorio criptográficamente seguro
 */
export function generateSecureToken(bytes = 32): string {
  return randomBytes(bytes).toString('hex')
}
