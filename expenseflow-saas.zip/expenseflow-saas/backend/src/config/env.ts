// backend/src/config/env.ts
import { z } from 'zod'

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().default(3001),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),

  // Base de datos
  DATABASE_URL: z.string().url(),

  // Redis
  REDIS_URL: z.string().default('redis://localhost:6379'),

  // JWT - usar claves RSA en producción
  JWT_PRIVATE_KEY: z.string(),  // RS256 private key
  JWT_PUBLIC_KEY: z.string(),   // RS256 public key
  JWT_ACCESS_EXPIRES: z.string().default('15m'),
  JWT_REFRESH_EXPIRES: z.string().default('7d'),

  // Cookies
  COOKIE_SECRET: z.string().min(32),

  // CORS
  ALLOWED_ORIGINS: z.string().default('http://localhost:3000'),
  ROOT_DOMAIN: z.string().default('expenseflow.app'),

  // Storage
  STORAGE_ENDPOINT: z.string().default('http://localhost:9000'),
  STORAGE_ACCESS_KEY: z.string(),
  STORAGE_SECRET_KEY: z.string(),
  STORAGE_BUCKET: z.string().default('expenseflow'),
  STORAGE_REGION: z.string().default('us-east-1'),
  STORAGE_USE_SSL: z.coerce.boolean().default(false),

  // Email
  SMTP_HOST: z.string().default('smtp.gmail.com'),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_USER: z.string().email(),
  SMTP_PASS: z.string(),
  EMAIL_FROM: z.string().default('ExpenseFlow <noreply@expenseflow.app>'),

  // Encriptación de datos sensibles (ERP credentials, etc.)
  ENCRYPTION_KEY: z.string().length(64), // 32 bytes en hex

  // App
  APP_URL: z.string().url().default('http://localhost:3000'),
  API_URL: z.string().url().default('http://localhost:3001'),
})

function validateEnv() {
  const result = envSchema.safeParse(process.env)
  if (!result.success) {
    console.error('❌ Variables de entorno inválidas:')
    console.error(result.error.flatten().fieldErrors)
    process.exit(1)
  }
  return result.data
}

export const env = validateEnv()
