// backend/src/modules/expenses/expense.service.ts
import { getTenantDB } from '../../config/database'
import { storageService } from '../../config/storage'
import { queueService } from '../../utils/queue'
import { auditLog } from '../../utils/audit'
import { v4 as uuidv4 } from 'uuid'

// ─── CREAR SOLICITUD ──────────────────────────────────────────────────────────

export async function createExpenseRequest(
  tenantSchema: string,
  userId: string,
  data: {
    expenseType: 'travel' | 'petty_cash' | 'reimbursement' | 'advance'
    title: string
    description?: string
    justification?: string
    amount: number
    currency?: string
    costCenterId?: string
    deptId?: string
    travelOrigin?: string
    travelDestination?: string
    travelStart?: string
    travelEnd?: string
    items?: Array<{
      category: string; description: string; amount: number; expenseDate?: string; vendor?: string
    }>
  },
  ip: string
) {
  const db = getTenantDB(tenantSchema)

  // 1. Obtener workflow por defecto o por tipo
  const wfResult = await db.query(
    `SELECT id FROM ${tenantSchema}.workflow_templates
     WHERE is_active = true AND ($1 = ANY(expense_type) OR expense_type @> '["all"]')
     ORDER BY id LIMIT 1`,
    [data.expenseType]
  )
  const workflowId = wfResult.rows[0]?.id || 'wf_default'

  // 2. Generar código único
  const seqResult = await db.query(`SELECT nextval('${tenantSchema}.expense_code_seq') as seq`)
  const seq = String(seqResult.rows[0].seq).padStart(6, '0')
  const year = new Date().getFullYear()
  const code = `EF-${year}-${seq}`

  const expenseId = uuidv4()

  // 3. Insertar solicitud
  await db.query(
    `INSERT INTO ${tenantSchema}.expense_requests
     (id, code, requester_id, dept_id, cost_center_id, workflow_id,
      expense_type, title, description, justification,
      currency, amount_requested, travel_origin, travel_destination,
      travel_start, travel_end, status, current_stage, submitted_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'pending',1,NOW())`,
    [
      expenseId, code, userId,
      data.deptId || null, data.costCenterId || null, workflowId,
      data.expenseType, data.title, data.description || null, data.justification || null,
      data.currency || 'CLP', data.amount,
      data.travelOrigin || null, data.travelDestination || null,
      data.travelStart || null, data.travelEnd || null,
    ]
  )

  // 4. Insertar ítems si hay
  if (data.items?.length) {
    for (const item of data.items) {
      await db.query(
        `INSERT INTO ${tenantSchema}.expense_items
         (id, expense_id, category, description, amount, expense_date, vendor)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [uuidv4(), expenseId, item.category, item.description, item.amount,
         item.expenseDate || null, item.vendor || null]
      )
    }
  }

  // 5. Crear primer approval step (pendiente)
  const firstStage = await db.query(
    `SELECT * FROM ${tenantSchema}.workflow_stages
     WHERE workflow_id=$1 AND stage_order=1`,
    [workflowId]
  )

  if (firstStage.rows[0]) {
    const stage = firstStage.rows[0]
    const dueAt = new Date(Date.now() + stage.sla_hours * 60 * 60 * 1000)
    await db.query(
      `INSERT INTO ${tenantSchema}.approval_steps
       (id, expense_id, stage_id, stage_order, stage_name, action, due_at)
       VALUES ($1,$2,$3,$4,$5,'pending',$6)`,
      [uuidv4(), expenseId, stage.id, 1, stage.name, dueAt]
    )
  }

  // 6. Encolar notificaciones
  await queueService.add('notify-approvers', { tenantSchema, expenseId, stage: 1 })

  await auditLog({
    userId,
    tenantSchema,
    action: 'EXPENSE_CREATED',
    resource: 'expense',
    resourceId: expenseId,
    ip,
  })

  return { id: expenseId, code }
}

// ─── APROBAR / RECHAZAR ───────────────────────────────────────────────────────

export async function processApproval(
  tenantSchema: string,
  expenseId: string,
  approverId: string,
  action: 'approved' | 'rejected' | 'returned',
  comment: string | undefined,
  ip: string
) {
  const db = getTenantDB(tenantSchema)

  // 1. Obtener solicitud actual
  const expResult = await db.query(
    `SELECT er.*, wt.id as wf_id FROM ${tenantSchema}.expense_requests er
     JOIN ${tenantSchema}.workflow_templates wt ON er.workflow_id = wt.id
     WHERE er.id=$1 AND er.status IN ('pending','in_review')`,
    [expenseId]
  )
  const expense = expResult.rows[0]
  if (!expense) throw new Error('Solicitud no encontrada o no está pendiente de aprobación')

  // 2. Verificar que el aprobador tiene permiso para esta etapa
  const stepResult = await db.query(
    `SELECT as2.*, ws.approver_role_id FROM ${tenantSchema}.approval_steps as2
     JOIN ${tenantSchema}.workflow_stages ws ON as2.stage_id = ws.id
     WHERE as2.expense_id=$1 AND as2.action='pending'
     ORDER BY as2.stage_order LIMIT 1`,
    [expenseId]
  )
  const currentStep = stepResult.rows[0]
  if (!currentStep) throw new Error('No hay etapas pendientes')

  // Verificar rol del aprobador
  const roleCheck = await db.query(
    `SELECT 1 FROM ${tenantSchema}.user_roles ur
     WHERE ur.user_id=$1 AND ur.role_id=$2`,
    [approverId, currentStep.approver_role_id]
  )
  if (!roleCheck.rows[0]) {
    throw new Error('No tienes permisos para aprobar esta solicitud en la etapa actual')
  }

  // 3. Actualizar el step actual
  await db.query(
    `UPDATE ${tenantSchema}.approval_steps
     SET action=$1, approver_id=$2, comment=$3, ip=$4, acted_at=NOW()
     WHERE id=$5`,
    [action, approverId, comment || null, ip, currentStep.id]
  )

  // 4. Determinar siguiente acción según el resultado
  if (action === 'rejected') {
    // Rechazar definitivamente
    await db.query(
      `UPDATE ${tenantSchema}.expense_requests
       SET status='rejected', completed_at=NOW(), updated_at=NOW() WHERE id=$1`,
      [expenseId]
    )
    await queueService.add('notify-requester', { tenantSchema, expenseId, action: 'rejected', comment })

  } else if (action === 'returned') {
    // Devolver al solicitante para correcciones
    await db.query(
      `UPDATE ${tenantSchema}.expense_requests
       SET status='draft', current_stage=1, updated_at=NOW() WHERE id=$1`,
      [expenseId]
    )
    await queueService.add('notify-requester', { tenantSchema, expenseId, action: 'returned', comment })

  } else {
    // Aprobado — buscar siguiente etapa
    const nextStage = await db.query(
      `SELECT * FROM ${tenantSchema}.workflow_stages
       WHERE workflow_id=$1 AND stage_order=$2`,
      [expense.workflow_id, expense.current_stage + 1]
    )

    if (nextStage.rows[0]) {
      // Hay más etapas
      const next = nextStage.rows[0]
      const dueAt = new Date(Date.now() + next.sla_hours * 60 * 60 * 1000)

      await db.query(
        `UPDATE ${tenantSchema}.expense_requests
         SET status='in_review', current_stage=$1, updated_at=NOW() WHERE id=$2`,
        [expense.current_stage + 1, expenseId]
      )

      await db.query(
        `INSERT INTO ${tenantSchema}.approval_steps
         (id, expense_id, stage_id, stage_order, stage_name, action, due_at)
         VALUES ($1,$2,$3,$4,$5,'pending',$6)`,
        [uuidv4(), expenseId, next.id, next.stage_order, next.name, dueAt]
      )

      await queueService.add('notify-approvers', {
        tenantSchema, expenseId, stage: expense.current_stage + 1
      })

    } else {
      // Aprobación final
      await db.query(
        `UPDATE ${tenantSchema}.expense_requests
         SET status='approved', completed_at=NOW(), updated_at=NOW() WHERE id=$1`,
        [expenseId]
      )
      await queueService.add('notify-requester', { tenantSchema, expenseId, action: 'approved' })
      
      // Si está configurado auto-export al ERP
      await queueService.add('check-auto-export', { tenantSchema, expenseId })
    }
  }

  await auditLog({
    userId: approverId,
    tenantSchema,
    action: `EXPENSE_${action.toUpperCase()}`,
    resource: 'expense',
    resourceId: expenseId,
    metadata: { comment },
    ip,
  })

  return { success: true, action }
}

// ─── SUBIR ARCHIVO ────────────────────────────────────────────────────────────

export async function uploadAttachment(
  tenantSchema: string,
  expenseId: string,
  uploaderId: string,
  file: {
    filename: string
    mimetype: string
    data: Buffer
  }
) {
  // 1. Validar tipo MIME (no solo extensión)
  const allowedMimes = [
    'image/jpeg', 'image/png', 'image/webp',
    'application/pdf',
  ]
  if (!allowedMimes.includes(file.mimetype)) {
    throw new Error(`Tipo de archivo no permitido: ${file.mimetype}`)
  }

  // 2. Validar tamaño
  if (file.data.length > 10 * 1024 * 1024) {
    throw new Error('El archivo supera el límite de 10MB')
  }

  // 3. Nombre seguro para almacenamiento (UUID, nunca el nombre original)
  const ext = file.filename.split('.').pop()?.toLowerCase()
  const storedName = `${uuidv4()}.${ext}`
  const storagePath = `${tenantSchema}/expenses/${expenseId}/${storedName}`

  // 4. Subir a storage
  await storageService.upload(storagePath, file.data, file.mimetype)

  // 5. Encolar escaneo de virus
  await queueService.add('virus-scan', {
    tenantSchema,
    expenseId,
    storagePath,
    filename: file.filename,
  })

  // 6. Guardar en DB
  const db = getTenantDB(tenantSchema)
  const attachmentId = uuidv4()

  await db.query(
    `INSERT INTO ${tenantSchema}.attachments
     (id, expense_id, uploader_id, filename, stored_name, storage_path, mime_type, size_bytes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [attachmentId, expenseId, uploaderId, file.filename, storedName, storagePath,
     file.mimetype, file.data.length]
  )

  return { id: attachmentId, filename: file.filename }
}

// ─── URL FIRMADA PARA DESCARGA ─────────────────────────────────────────────────

export async function getSignedDownloadUrl(
  tenantSchema: string,
  attachmentId: string,
  requesterId: string
) {
  const db = getTenantDB(tenantSchema)
  const result = await db.query(
    `SELECT a.*, er.requester_id FROM ${tenantSchema}.attachments a
     JOIN ${tenantSchema}.expense_requests er ON a.expense_id = er.id
     WHERE a.id=$1`,
    [attachmentId]
  )
  const attachment = result.rows[0]
  if (!attachment) throw new Error('Archivo no encontrado')

  // URL firmada con expiración de 15 minutos
  const url = await storageService.getSignedUrl(attachment.storage_path, 900)
  return { url, expiresIn: 900 }
}

// ─── LISTAR SOLICITUDES ───────────────────────────────────────────────────────

export async function listExpenses(
  tenantSchema: string,
  userId: string,
  permissions: string[],
  filters: { status?: string; type?: string; page?: number; limit?: number }
) {
  const db = getTenantDB(tenantSchema)
  const isAdmin = permissions.includes('*') || permissions.includes('expenses.read')
  const page = filters.page || 1
  const limit = Math.min(filters.limit || 20, 100)
  const offset = (page - 1) * limit

  let whereClause = 'WHERE er.deleted_at IS NULL'
  const params: any[] = []
  let paramIdx = 1

  // Empleados solo ven sus propias solicitudes
  if (!isAdmin) {
    whereClause += ` AND er.requester_id = $${paramIdx++}`
    params.push(userId)
  }

  if (filters.status) {
    whereClause += ` AND er.status = $${paramIdx++}`
    params.push(filters.status)
  }

  if (filters.type) {
    whereClause += ` AND er.expense_type = $${paramIdx++}`
    params.push(filters.type)
  }

  const result = await db.query(
    `SELECT er.id, er.code, er.expense_type, er.title, er.status,
            er.amount_requested, er.currency, er.created_at, er.current_stage,
            u.name as requester_name, u.email as requester_email
     FROM ${tenantSchema}.expense_requests er
     JOIN ${tenantSchema}.users u ON er.requester_id = u.id
     ${whereClause}
     ORDER BY er.created_at DESC
     LIMIT $${paramIdx++} OFFSET $${paramIdx}`,
    [...params, limit, offset]
  )

  const countResult = await db.query(
    `SELECT COUNT(*) FROM ${tenantSchema}.expense_requests er ${whereClause}`,
    params
  )

  return {
    expenses: result.rows,
    total: parseInt(countResult.rows[0].count),
    page,
    limit,
  }
}
