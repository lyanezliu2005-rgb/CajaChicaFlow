// backend/src/modules/erp/erp.service.ts
import { getTenantDB } from '../../config/database'
import { decrypt, encrypt } from '../../utils/crypto'
import { auditLog } from '../../utils/audit'

// ─── EXPORTAR AL ERP ──────────────────────────────────────────────────────────

export async function exportToERP(
  tenantSchema: string,
  expenseIds: string[],
  userId: string,
  ip: string
) {
  const db = getTenantDB(tenantSchema)

  // 1. Obtener config ERP activa
  const configResult = await db.query(
    `SELECT * FROM ${tenantSchema}.erp_configs WHERE is_active=true LIMIT 1`
  )
  const erpConfig = configResult.rows[0]
  if (!erpConfig) throw new Error('No hay integración ERP activa configurada')

  // 2. Obtener solicitudes aprobadas para exportar
  const expenses = await db.query(
    `SELECT er.*, u.name as requester_name, u.email as requester_email,
            cc.code as cost_center_code, cc.name as cost_center_name,
            array_agg(json_build_object(
              'category', ei.category, 'description', ei.description,
              'amount', ei.amount, 'date', ei.expense_date
            )) as items
     FROM ${tenantSchema}.expense_requests er
     JOIN ${tenantSchema}.users u ON er.requester_id = u.id
     LEFT JOIN ${tenantSchema}.cost_centers cc ON er.cost_center_id = cc.id
     LEFT JOIN ${tenantSchema}.expense_items ei ON ei.expense_id = er.id
     WHERE er.id = ANY($1) AND er.status = 'approved' AND er.erp_exported_at IS NULL
     GROUP BY er.id, u.name, u.email, cc.code, cc.name`,
    [expenseIds]
  )

  if (!expenses.rows.length) {
    throw new Error('No se encontraron solicitudes aprobadas pendientes de exportación')
  }

  // 3. Transformar al formato del ERP (usando payload_map configurado)
  const payloadMap = erpConfig.payload_map || {}
  const payload = buildERPPayload(expenses.rows, payloadMap, erpConfig.erp_type)

  // 4. Desencriptar credenciales
  const credentials = erpConfig.credentials
    ? JSON.parse(await decrypt(erpConfig.credentials.toString('hex')))
    : {}

  // 5. Llamar al ERP
  const result = await callERPEndpoint(erpConfig, credentials, payload)

  // 6. Marcar como exportados
  await db.query(
    `UPDATE ${tenantSchema}.expense_requests
     SET erp_exported_at=NOW(), erp_reference=$1, erp_status='exported', status='exported', updated_at=NOW()
     WHERE id = ANY($2)`,
    [result.reference, expenseIds]
  )

  await auditLog({
    userId, tenantSchema,
    action: 'ERP_EXPORT',
    resource: 'expense',
    metadata: { expenseIds, erpType: erpConfig.erp_type, reference: result.reference },
    ip,
  })

  return { exported: expenses.rows.length, reference: result.reference }
}

// ─── GUARDAR CONFIG ERP ───────────────────────────────────────────────────────

export async function saveERPConfig(
  tenantSchema: string,
  config: {
    erpType: string
    name: string
    endpoint: string
    authType: string
    credentials: Record<string, string>
    headers?: Record<string, string>
    payloadMap?: Record<string, string>
  },
  userId: string
) {
  const db = getTenantDB(tenantSchema)

  // Encriptar credenciales con AES-256-GCM
  const encryptedCreds = await encrypt(JSON.stringify(config.credentials))

  const existing = await db.query(
    `SELECT id FROM ${tenantSchema}.erp_configs WHERE erp_type=$1`,
    [config.erpType]
  )

  if (existing.rows[0]) {
    await db.query(
      `UPDATE ${tenantSchema}.erp_configs
       SET name=$1, endpoint=$2, auth_type=$3, credentials=$4, headers=$5,
           payload_map=$6, updated_at=NOW()
       WHERE erp_type=$7`,
      [config.name, config.endpoint, config.authType,
       Buffer.from(encryptedCreds, 'hex'), config.headers || {},
       config.payloadMap || {}, config.erpType]
    )
  } else {
    await db.query(
      `INSERT INTO ${tenantSchema}.erp_configs
       (id, erp_type, name, endpoint, auth_type, credentials, headers, payload_map)
       VALUES (gen_random_uuid(),$1,$2,$3,$4,$5,$6,$7)`,
      [config.erpType, config.name, config.endpoint, config.authType,
       Buffer.from(encryptedCreds, 'hex'), config.headers || {},
       config.payloadMap || {}]
    )
  }

  return { success: true }
}

// ─── TEST CONEXIÓN ERP ────────────────────────────────────────────────────────

export async function testERPConnection(
  tenantSchema: string,
  erpType: string
): Promise<{ connected: boolean; message: string }> {
  const db = getTenantDB(tenantSchema)
  const result = await db.query(
    `SELECT * FROM ${tenantSchema}.erp_configs WHERE erp_type=$1`,
    [erpType]
  )
  const config = result.rows[0]
  if (!config) return { connected: false, message: 'Configuración no encontrada' }

  try {
    const credentials = JSON.parse(await decrypt(config.credentials.toString('hex')))
    const testResult = await callERPEndpoint(config, credentials, { test: true }, true)
    return { connected: true, message: 'Conexión exitosa' }
  } catch (err: any) {
    return { connected: false, message: err.message }
  }
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function buildERPPayload(expenses: any[], payloadMap: any, erpType: string) {
  const items = expenses.map(exp => ({
    id: exp.code,
    type: exp.expense_type,
    description: exp.title,
    requester: exp.requester_name,
    requester_email: exp.requester_email,
    cost_center: exp.cost_center_code,
    amount: parseFloat(exp.amount_approved || exp.amount_requested),
    currency: exp.currency,
    date: exp.completed_at,
    items: exp.items?.filter((i: any) => i.category),
    status: 'approved',
  }))

  // Formatos específicos por ERP
  switch (erpType) {
    case 'sap':
      return {
        Header: { CompanyCode: payloadMap.companyCode || '1000', DocumentType: 'KR' },
        Items: items.map(i => ({
          GL_Account: payloadMap.glAccount || '6000000',
          Cost_Center: i.cost_center,
          Amount: i.amount,
          Currency: i.currency,
          Reference: i.id,
          Text: i.description,
        })),
      }
    case 'oracle':
      return { transactions: items }
    case 'dynamics':
      return { value: items }
    default:
      return { expenses: items, exported_at: new Date().toISOString() }
  }
}

async function callERPEndpoint(config: any, credentials: any, payload: any, isTest = false) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(config.headers || {}),
  }

  // Agregar auth según tipo
  switch (config.auth_type) {
    case 'bearer':
      headers['Authorization'] = `Bearer ${credentials.token}`
      break
    case 'basic':
      const encoded = Buffer.from(`${credentials.username}:${credentials.password}`).toString('base64')
      headers['Authorization'] = `Basic ${encoded}`
      break
    case 'api_key':
      headers[credentials.key_header || 'X-API-Key'] = credentials.api_key
      break
  }

  const response = await fetch(isTest ? `${config.endpoint}/ping` : config.endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15000), // 15s timeout
  })

  if (!response.ok) {
    throw new Error(`ERP respondió con error ${response.status}: ${await response.text()}`)
  }

  const data = await response.json().catch(() => ({}))
  return { reference: data.reference || data.id || `ERP-${Date.now()}` }
}
