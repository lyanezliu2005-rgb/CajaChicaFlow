// backend/src/modules/tenants/tenant.service.ts
import { prisma } from '../../config/database'
import { getTenantDB, rawQuery } from '../../config/database'
import fs from 'fs/promises'
import path from 'path'
import { auditLog } from '../../utils/audit'
import { sendEmail } from '../../utils/email'
import { invalidateTenantCache } from '../../middleware/tenant.middleware'
import argon2 from 'argon2'
import { v4 as uuidv4 } from 'uuid'

const ARGON2_OPTIONS = { type: argon2.argon2id, memoryCost: 65536, timeCost: 3, parallelism: 4 }

// ─── CREAR EMPRESA ─────────────────────────────────────────────────────────────

export async function createTenant(data: {
  name: string
  slug: string
  rut?: string
  adminEmail: string
  adminName: string
  plan?: 'STARTER' | 'BUSINESS' | 'ENTERPRISE'
  country?: string
  phone?: string
  superAdminId: string
}) {
  const slug = data.slug.toLowerCase().replace(/[^a-z0-9-]/g, '-')

  // Verificar slug único
  const existing = await prisma.tenant.findUnique({ where: { slug } })
  if (existing) throw new Error(`Ya existe una empresa con el slug "${slug}"`)

  // Nombre del schema PostgreSQL (sin caracteres especiales)
  const schemaName = `t_${slug.replace(/-/g, '_')}`

  // 1. Crear registro en tabla pública
  const tenant = await prisma.tenant.create({
    data: {
      slug,
      name: data.name,
      rut: data.rut,
      adminEmail: data.adminEmail,
      adminName: data.adminName,
      schemaName,
      plan: data.plan || 'STARTER',
      status: 'ACTIVE',
      country: data.country || 'CL',
      phone: data.phone,
    },
  })

  // 2. Crear schema PostgreSQL con toda la estructura
  await provisionTenantSchema(schemaName)

  // 3. Crear usuario admin de la empresa
  const tempPassword = generateSecurePassword()
  const passwordHash = await argon2.hash(tempPassword, ARGON2_OPTIONS)

  const db = getTenantDB(schemaName)
  const adminId = uuidv4()

  await db.query(
    `INSERT INTO ${schemaName}.users (id, email, password_hash, name, email_verified)
     VALUES ($1, $2, $3, $4, true)`,
    [adminId, data.adminEmail.toLowerCase(), passwordHash, data.adminName]
  )

  // Asignar rol company_admin
  await db.query(
    `INSERT INTO ${schemaName}.user_roles (user_id, role_id)
     SELECT $1, id FROM ${schemaName}.roles WHERE slug = 'company_admin'`,
    [adminId]
  )

  // 4. Enviar email de bienvenida con credenciales temporales
  await sendEmail({
    to: data.adminEmail,
    subject: `Bienvenido a ExpenseFlow — ${data.name}`,
    template: 'tenant-welcome',
    vars: {
      name: data.adminName,
      company: data.name,
      email: data.adminEmail,
      tempPassword,
      loginUrl: `https://${slug}.expenseflow.app/auth/login`,
    },
  })

  // 5. Audit log
  await auditLog({
    actorId: data.superAdminId,
    actorType: 'super_admin',
    action: 'TENANT_CREATED',
    resource: 'tenant',
    resourceId: tenant.id,
    metadata: { slug, name: data.name },
    ip: '0.0.0.0',
  })

  return { tenant, adminId, tempPassword }
}

// ─── PROVISIONAR SCHEMA ────────────────────────────────────────────────────────

async function provisionTenantSchema(schemaName: string) {
  // Leer el template SQL
  const templatePath = path.join(__dirname, '../../../prisma/tenant-schema.sql')
  let sql = await fs.readFile(templatePath, 'utf-8')

  // Reemplazar placeholder con nombre del schema
  // CRÍTICO: validar que schemaName sea seguro (solo letras, números, guiones bajos)
  if (!/^t_[a-z0-9_]+$/.test(schemaName)) {
    throw new Error(`Nombre de schema inválido: ${schemaName}`)
  }
  sql = sql.replaceAll('{SCHEMA}', schemaName)

  // Ejecutar SQL de provisioning
  await rawQuery(sql)
}

// ─── LISTAR EMPRESAS ───────────────────────────────────────────────────────────

export async function listTenants(options: {
  page?: number
  limit?: number
  status?: string
  search?: string
}) {
  const page = options.page || 1
  const limit = Math.min(options.limit || 20, 100)
  const skip = (page - 1) * limit

  const where: any = { deletedAt: null }
  if (options.status) where.status = options.status
  if (options.search) {
    where.OR = [
      { name: { contains: options.search, mode: 'insensitive' } },
      { slug: { contains: options.search, mode: 'insensitive' } },
      { adminEmail: { contains: options.search, mode: 'insensitive' } },
    ]
  }

  const [tenants, total] = await Promise.all([
    prisma.tenant.findMany({
      where,
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, slug: true, name: true, plan: true, status: true,
        adminEmail: true, adminName: true, country: true,
        maxUsers: true, createdAt: true,
      },
    }),
    prisma.tenant.count({ where }),
  ])

  return { tenants, total, page, limit, pages: Math.ceil(total / limit) }
}

// ─── ACTUALIZAR EMPRESA ────────────────────────────────────────────────────────

export async function updateTenant(
  tenantId: string,
  data: Partial<{
    name: string; plan: string; status: string; maxUsers: number
    maxStorage: number; notes: string; primaryColor: string
  }>,
  superAdminId: string
) {
  const tenant = await prisma.tenant.update({
    where: { id: tenantId },
    data: { ...data, updatedAt: new Date() },
  })

  // Invalidar cache
  await invalidateTenantCache(tenant.slug)

  await auditLog({
    actorId: superAdminId,
    actorType: 'super_admin',
    action: 'TENANT_UPDATED',
    resource: 'tenant',
    resourceId: tenantId,
    metadata: data,
    ip: '0.0.0.0',
  })

  return tenant
}

// ─── SUSPENDER EMPRESA ─────────────────────────────────────────────────────────

export async function suspendTenant(tenantId: string, reason: string, superAdminId: string) {
  const tenant = await prisma.tenant.update({
    where: { id: tenantId },
    data: { status: 'SUSPENDED' },
  })

  await invalidateTenantCache(tenant.slug)

  // Notificar al admin de la empresa
  await sendEmail({
    to: tenant.adminEmail,
    subject: 'Tu cuenta en ExpenseFlow ha sido suspendida',
    template: 'tenant-suspended',
    vars: { name: tenant.adminName, company: tenant.name, reason },
  })

  return tenant
}

// ─── STATS GLOBALES ────────────────────────────────────────────────────────────

export async function getGlobalStats() {
  const [total, active, trial, suspended] = await Promise.all([
    prisma.tenant.count({ where: { deletedAt: null } }),
    prisma.tenant.count({ where: { status: 'ACTIVE', deletedAt: null } }),
    prisma.tenant.count({ where: { status: 'TRIAL', deletedAt: null } }),
    prisma.tenant.count({ where: { status: 'SUSPENDED', deletedAt: null } }),
  ])

  const byPlan = await prisma.tenant.groupBy({
    by: ['plan'],
    where: { deletedAt: null, status: 'ACTIVE' },
    _count: true,
  })

  return { total, active, trial, suspended, byPlan }
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function generateSecurePassword(): string {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$'
  const crypto = require('crypto')
  let password = ''
  for (let i = 0; i < 16; i++) {
    password += chars[crypto.randomInt(chars.length)]
  }
  return password
}
