// backend/src/modules/auth/auth.service.ts
import argon2 from 'argon2'
import { authenticator } from 'otplib'
import QRCode from 'qrcode'
import { v4 as uuidv4 } from 'uuid'
import { prisma } from '../../config/database'
import { getTenantDB } from '../../config/database'
import { redisClient } from '../../config/redis'
import { generateAccessToken, revokeToken } from '../../middleware/auth.middleware'
import { env } from '../../config/env'
import { sendEmail } from '../../utils/email'
import { auditLog } from '../../utils/audit'
import jwt from 'jsonwebtoken'

// ─── ARGON2 CONFIG (seguro contra ataques de fuerza bruta) ────────────────────
const ARGON2_OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 65536,  // 64 MB
  timeCost: 3,
  parallelism: 4,
}

// ─── SUPER ADMIN LOGIN ────────────────────────────────────────────────────────

export async function superAdminLogin(
  email: string,
  password: string,
  mfaCode: string | undefined,
  ip: string,
  userAgent: string
) {
  // 1. Buscar super admin (timing-safe: siempre hacer hash aunque no exista)
  const admin = await prisma.superAdmin.findUnique({ where: { email: email.toLowerCase() } })

  // Dummy hash para timing-safe (evita user enumeration)
  const dummyHash = '$argon2id$v=19$m=65536,t=3,p=4$dummy'
  const hash = admin?.passwordHash || dummyHash

  // 2. Verificar contraseña
  const valid = await argon2.verify(hash, password, ARGON2_OPTIONS)

  if (!admin || !valid) {
    // Registrar intento fallido
    await auditLog({
      actorId: email,
      actorType: 'super_admin',
      action: 'LOGIN_FAILED',
      resource: 'auth',
      ip,
    })
    throw new Error('Credenciales inválidas')
  }

  // 3. Verificar MFA si está habilitado
  if (admin.mfaEnabled) {
    if (!mfaCode) throw new Error('Código MFA requerido')
    const validMFA = authenticator.verify({
      token: mfaCode,
      secret: admin.mfaSecret!,
    })
    if (!validMFA) {
      await auditLog({ actorId: admin.id, actorType: 'super_admin', action: 'MFA_FAILED', resource: 'auth', ip })
      throw new Error('Código MFA inválido')
    }
  }

  // 4. Generar tokens
  const { accessToken, refreshToken } = await generateTokenPair({
    sub: admin.id,
    type: 'super_admin',
    roles: ['super_admin'],
    permissions: ['*'],
  }, ip, userAgent, 'super_admin', admin.id)

  // 5. Actualizar último login
  await prisma.superAdmin.update({
    where: { id: admin.id },
    data: { lastLoginAt: new Date(), lastLoginIp: ip },
  })

  await auditLog({ actorId: admin.id, actorType: 'super_admin', action: 'LOGIN_SUCCESS', resource: 'auth', ip })

  return { accessToken, refreshToken, user: { id: admin.id, email: admin.email, name: admin.name } }
}

// ─── TENANT USER LOGIN ────────────────────────────────────────────────────────

export async function tenantUserLogin(
  email: string,
  password: string,
  mfaCode: string | undefined,
  tenantSchema: string,
  ip: string,
  userAgent: string
) {
  const db = getTenantDB(tenantSchema)

  // 1. Buscar usuario en schema del tenant
  const users = await db.query(
    `SELECT id, email, password_hash, name, mfa_enabled, mfa_secret,
            login_attempts, locked_until, is_active
     FROM ${tenantSchema}.users WHERE email = $1 AND deleted_at IS NULL`,
    [email.toLowerCase()]
  )

  const user = users.rows[0]

  // 2. Verificar bloqueo por intentos fallidos
  if (user?.locked_until && new Date(user.locked_until) > new Date()) {
    const minutesLeft = Math.ceil(
      (new Date(user.locked_until).getTime() - Date.now()) / 60000
    )
    throw new Error(`Cuenta bloqueada. Intenta en ${minutesLeft} minutos.`)
  }

  // Timing-safe
  const dummyHash = '$argon2id$v=19$m=65536,t=3,p=4$dummy'
  const hash = user?.password_hash || dummyHash
  const valid = await argon2.verify(hash, password, ARGON2_OPTIONS)

  if (!user || !valid || !user.is_active) {
    // Incrementar contador de intentos
    if (user) {
      const attempts = (user.login_attempts || 0) + 1
      const lockedUntil = attempts >= 5
        ? new Date(Date.now() + Math.pow(2, attempts - 5) * 60000) // exponential backoff
        : null
      await db.query(
        `UPDATE ${tenantSchema}.users SET login_attempts=$1, locked_until=$2 WHERE id=$3`,
        [attempts, lockedUntil, user.id]
      )
    }
    throw new Error('Credenciales inválidas')
  }

  // 3. Verificar MFA
  if (user.mfa_enabled) {
    if (!mfaCode) throw new Error('Código MFA requerido')
    const validMFA = authenticator.verify({ token: mfaCode, secret: user.mfa_secret })
    if (!validMFA) throw new Error('Código MFA inválido')
  }

  // 4. Obtener roles y permisos
  const rolesResult = await db.query(
    `SELECT r.slug, r.permissions FROM ${tenantSchema}.user_roles ur
     JOIN ${tenantSchema}.roles r ON ur.role_id = r.id
     WHERE ur.user_id = $1`,
    [user.id]
  )
  const roles = rolesResult.rows.map((r: any) => r.slug)
  const permissions = [...new Set(rolesResult.rows.flatMap((r: any) => r.permissions))] as string[]

  // 5. Generar tokens
  const { accessToken, refreshToken } = await generateTokenPair({
    sub: user.id,
    type: 'tenant_user',
    tenantSchema,
    roles,
    permissions,
  }, ip, userAgent, 'tenant', user.id, tenantSchema)

  // 6. Reset intentos fallidos y actualizar último login
  await db.query(
    `UPDATE ${tenantSchema}.users SET login_attempts=0, locked_until=NULL, last_login_at=NOW(), last_login_ip=$1 WHERE id=$2`,
    [ip, user.id]
  )

  return { accessToken, refreshToken, user: { id: user.id, email: user.email, name: user.name, roles } }
}

// ─── REFRESH TOKEN ────────────────────────────────────────────────────────────

export async function refreshAccessToken(
  refreshToken: string,
  ip: string,
  userAgent: string
) {
  // 1. Verificar token
  let payload: any
  try {
    payload = jwt.verify(refreshToken, env.JWT_PUBLIC_KEY, { algorithms: ['RS256'] })
  } catch {
    throw new Error('Refresh token inválido')
  }

  // 2. Verificar en blacklist
  const blacklisted = await redisClient.get(`blacklist:${payload.jti}`)
  if (blacklisted) throw new Error('Token revocado')

  // 3. Buscar en DB y verificar que no esté revocado
  const tokenHash = await hashToken(refreshToken)
  
  let storedToken: any
  if (payload.type === 'super_admin') {
    storedToken = await prisma.superAdminRefreshToken.findUnique({
      where: { tokenHash },
    })
  } else {
    const db = getTenantDB(payload.tenantSchema)
    const result = await db.query(
      `SELECT * FROM ${payload.tenantSchema}.refresh_tokens WHERE token_hash=$1`,
      [tokenHash]
    )
    storedToken = result.rows[0]
  }

  if (!storedToken || storedToken.revoked_at || new Date(storedToken.expires_at) < new Date()) {
    throw new Error('Refresh token expirado o revocado')
  }

  // 4. TOKEN ROTATION: revocar el token actual
  await revokeToken(payload.jti, payload.exp)
  if (payload.type === 'super_admin') {
    await prisma.superAdminRefreshToken.update({
      where: { tokenHash },
      data: { revokedAt: new Date() },
    })
  } else {
    const db = getTenantDB(payload.tenantSchema)
    await db.query(
      `UPDATE ${payload.tenantSchema}.refresh_tokens SET revoked_at=NOW() WHERE token_hash=$1`,
      [tokenHash]
    )
  }

  // 5. Emitir nuevos tokens
  return generateTokenPair({
    sub: payload.sub,
    type: payload.type,
    tenantSchema: payload.tenantSchema,
    roles: payload.roles,
    permissions: payload.permissions,
  }, ip, userAgent, payload.type === 'super_admin' ? 'super_admin' : 'tenant', payload.sub, payload.tenantSchema)
}

// ─── LOGOUT ───────────────────────────────────────────────────────────────────

export async function logout(accessJti: string, accessExp: number, refreshToken?: string) {
  // Revocar access token
  await revokeToken(accessJti, accessExp)

  // Revocar refresh token si se provee
  if (refreshToken) {
    try {
      const payload: any = jwt.verify(refreshToken, env.JWT_PUBLIC_KEY, { algorithms: ['RS256'] })
      await revokeToken(payload.jti, payload.exp)
      const tokenHash = await hashToken(refreshToken)
      if (payload.type === 'super_admin') {
        await prisma.superAdminRefreshToken.updateMany({
          where: { tokenHash },
          data: { revokedAt: new Date() },
        })
      }
    } catch { /* ignorar errores en logout */ }
  }
}

// ─── MFA SETUP ────────────────────────────────────────────────────────────────

export async function setupMFA(userId: string, userEmail: string, isSuperAdmin: boolean) {
  const secret = authenticator.generateSecret()
  const otpauth = authenticator.keyuri(userEmail, 'ExpenseFlow', secret)
  const qrCode = await QRCode.toDataURL(otpauth)

  // Guardar secret temporalmente en Redis (se confirma con el primer código)
  await redisClient.setex(`mfa_setup:${userId}`, 300, secret) // 5 min

  return { secret, qrCode }
}

export async function confirmMFA(userId: string, code: string, isSuperAdmin: boolean, tenantSchema?: string) {
  const secret = await redisClient.get(`mfa_setup:${userId}`)
  if (!secret) throw new Error('Configuración MFA expirada. Inicia nuevamente.')

  const valid = authenticator.verify({ token: code, secret })
  if (!valid) throw new Error('Código inválido')

  // Guardar secret en DB
  if (isSuperAdmin) {
    await prisma.superAdmin.update({
      where: { id: userId },
      data: { mfaSecret: secret, mfaEnabled: true },
    })
  } else if (tenantSchema) {
    const db = getTenantDB(tenantSchema)
    await db.query(
      `UPDATE ${tenantSchema}.users SET mfa_secret=$1, mfa_enabled=true WHERE id=$2`,
      [secret, userId]
    )
  }

  await redisClient.del(`mfa_setup:${userId}`)
  return { success: true }
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

async function generateTokenPair(
  payload: any,
  ip: string,
  userAgent: string,
  actorType: string,
  userId: string,
  tenantSchema?: string
) {
  const jti = uuidv4()
  const refreshJti = uuidv4()

  const accessToken = jwt.sign(
    { ...payload, jti },
    env.JWT_PRIVATE_KEY,
    { algorithm: 'RS256', expiresIn: env.JWT_ACCESS_EXPIRES }
  )

  const refreshTokenValue = jwt.sign(
    { ...payload, jti: refreshJti, tokenType: 'refresh' },
    env.JWT_PRIVATE_KEY,
    { algorithm: 'RS256', expiresIn: env.JWT_REFRESH_EXPIRES }
  )

  const tokenHash = await hashToken(refreshTokenValue)
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)

  // Guardar refresh token en DB
  if (actorType === 'super_admin') {
    await prisma.superAdminRefreshToken.create({
      data: { superAdminId: userId, tokenHash, userAgent, ip, expiresAt },
    })
  } else if (tenantSchema) {
    const db = getTenantDB(tenantSchema)
    await db.query(
      `INSERT INTO ${tenantSchema}.refresh_tokens (user_id, token_hash, user_agent, ip, expires_at)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, tokenHash, userAgent, ip, expiresAt]
    )
  }

  return { accessToken, refreshToken: refreshTokenValue }
}

async function hashToken(token: string): Promise<string> {
  const crypto = await import('crypto')
  return crypto.createHash('sha256').update(token).digest('hex')
}
