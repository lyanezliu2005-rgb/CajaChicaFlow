// backend/src/server.ts
import Fastify from 'fastify'
import helmet from '@fastify/helmet'
import cors from '@fastify/cors'
import cookie from '@fastify/cookie'
import rateLimit from '@fastify/rate-limit'
import multipart from '@fastify/multipart'

import { env } from './config/env'
import { redisClient } from './config/redis'
import { authRoutes } from './modules/auth/auth.routes'
import { tenantRoutes } from './modules/tenants/tenant.routes'
import { userRoutes } from './modules/users/user.routes'
import { expenseRoutes } from './modules/expenses/expense.routes'
import { workflowRoutes } from './modules/workflows/workflow.routes'
import { erpRoutes } from './modules/erp/erp.routes'
import { tenantMiddleware } from './middleware/tenant.middleware'
import { authMiddleware } from './middleware/auth.middleware'

const app = Fastify({
  logger: {
    level: env.LOG_LEVEL,
    redact: ['req.headers.authorization', 'req.body.password', 'req.body.passwordHash'],
  },
  trustProxy: true,
  ajv: {
    customOptions: { removeAdditional: true, coerceTypes: false },
  },
})

async function buildApp() {
  // ─── SECURITY HEADERS ───────────────────────────────────────────────────────
  await app.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    frameguard: { action: 'deny' },
    noSniff: true,
    xssFilter: true,
    referrerPolicy: { policy: 'same-origin' },
  })

  // ─── CORS ────────────────────────────────────────────────────────────────────
  await app.register(cors, {
    origin: (origin, cb) => {
      const allowed = env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
      if (!origin || allowed.includes(origin) || origin.endsWith(`.${env.ROOT_DOMAIN}`)) {
        cb(null, true)
      } else {
        cb(new Error('Not allowed by CORS'), false)
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Tenant-ID'],
  })

  // ─── COOKIES ────────────────────────────────────────────────────────────────
  await app.register(cookie, {
    secret: env.COOKIE_SECRET,
    hook: 'onRequest',
  })

  // ─── RATE LIMITING ──────────────────────────────────────────────────────────
  await app.register(rateLimit, {
    global: true,
    max: 100,
    timeWindow: '1 minute',
    redis: redisClient,
    keyGenerator: (req) => `rl:${req.ip}`,
    errorResponseBuilder: () => ({
      statusCode: 429,
      error: 'Too Many Requests',
      message: 'Has excedido el límite de solicitudes. Intenta en 1 minuto.',
    }),
  })

  // ─── FILE UPLOADS ────────────────────────────────────────────────────────────
  await app.register(multipart, {
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB max
      files: 10,
      fields: 20,
    },
  })

  // ─── HEALTH CHECK ────────────────────────────────────────────────────────────
  app.get('/health', async () => ({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version,
  }))

  // ─── API ROUTES ──────────────────────────────────────────────────────────────

  // Auth pública (login, registro)
  await app.register(authRoutes, { prefix: '/api/v1/auth' })

  // Super Admin routes (requiere auth de super admin)
  await app.register(async (adminApp) => {
    adminApp.addHook('onRequest', authMiddleware('super_admin'))
    await adminApp.register(tenantRoutes, { prefix: '/tenants' })
  }, { prefix: '/api/v1/admin' })

  // Tenant routes (requiere auth de usuario + resolución de tenant)
  await app.register(async (tenantApp) => {
    tenantApp.addHook('onRequest', tenantMiddleware)
    tenantApp.addHook('onRequest', authMiddleware('tenant_user'))
    await tenantApp.register(userRoutes, { prefix: '/users' })
    await tenantApp.register(expenseRoutes, { prefix: '/expenses' })
    await tenantApp.register(workflowRoutes, { prefix: '/workflows' })
    await tenantApp.register(erpRoutes, { prefix: '/erp' })
  }, { prefix: '/api/v1/t' })

  // ─── ERROR HANDLER ──────────────────────────────────────────────────────────
  app.setErrorHandler((error, request, reply) => {
    // No exponer detalles de error en producción
    const statusCode = error.statusCode || 500
    const isProd = env.NODE_ENV === 'production'

    app.log.error({ err: error, req: { id: request.id, ip: request.ip } })

    reply.status(statusCode).send({
      statusCode,
      error: statusCode >= 500 ? 'Internal Server Error' : error.message,
      message: isProd && statusCode >= 500
        ? 'Ha ocurrido un error interno. Por favor contacta soporte.'
        : error.message,
      requestId: request.id,
    })
  })

  // ─── NOT FOUND ───────────────────────────────────────────────────────────────
  app.setNotFoundHandler((request, reply) => {
    reply.status(404).send({
      statusCode: 404,
      error: 'Not Found',
      message: `Ruta ${request.method} ${request.url} no encontrada`,
    })
  })

  return app
}

async function start() {
  try {
    const server = await buildApp()
    await server.listen({ port: env.PORT, host: '0.0.0.0' })
    console.log(`🚀 ExpenseFlow API corriendo en puerto ${env.PORT}`)
  } catch (err) {
    console.error('Error al iniciar el servidor:', err)
    process.exit(1)
  }
}

start()

export { buildApp }
