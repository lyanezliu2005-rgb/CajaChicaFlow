# ExpenseFlow SaaS — Arquitectura Completa

## Stack Tecnológico

### Backend
- **Runtime**: Node.js 20 LTS + TypeScript
- **Framework**: Fastify v4 (más rápido y seguro que Express)
- **ORM**: Prisma v5 (type-safe, migraciones automáticas)
- **Base de datos**: PostgreSQL 16 (multi-tenant con Row-Level Security)
- **Cache / Sesiones**: Redis 7
- **Autenticación**: JWT (access 15min) + Refresh Token (7 días) + MFA TOTP
- **Almacenamiento**: MinIO (self-hosted S3-compatible) o AWS S3
- **Cola de tareas**: BullMQ + Redis
- **Email**: Nodemailer + SMTP / AWS SES

### Frontend
- **Framework**: Next.js 14 (App Router, PWA)
- **UI**: Tailwind CSS + shadcn/ui
- **Estado global**: Zustand
- **Formularios**: React Hook Form + Zod
- **HTTP client**: Axios con interceptores
- **PWA**: next-pwa (service worker, offline, instalable)

### Infraestructura
- **Proxy / SSL**: Nginx + Certbot (Let's Encrypt)
- **Contenedores**: Docker + Docker Compose
- **CI/CD**: GitHub Actions
- **Monitoreo**: Prometheus + Grafana (opcional)

---

## Modelo Multi-Tenant

### Estrategia: Schema-per-tenant en PostgreSQL

```
PostgreSQL
├── schema: public          ← tablas globales (tenants, super_admins)
├── schema: tenant_acme     ← datos empresa ACME (aislados)
├── schema: tenant_copec    ← datos empresa COPEC (aislados)
└── schema: tenant_xyz      ← datos empresa XYZ (aislados)
```

**Ventajas de este enfoque:**
- Aislamiento total de datos por empresa
- Row-Level Security (RLS) como segunda capa
- Fácil backup/restore por empresa
- Cumplimiento GDPR / Ley 19.628 Chile

---

## Seguridad — Capas de Defensa

### 1. Red / Transporte
- TLS 1.3 obligatorio (Nginx)
- HSTS con preload
- Headers de seguridad: CSP, X-Frame-Options, CORP, COEP
- Rate limiting por IP + por usuario (Redis)
- Bloqueo automático tras 5 intentos fallidos (exponential backoff)

### 2. Autenticación
- JWT firmados con RS256 (par de claves asimétricas)
- Access Token: 15 minutos (en memoria, nunca en localStorage)
- Refresh Token: 7 días (HttpOnly + Secure + SameSite=Strict cookie)
- MFA con TOTP (Google Authenticator compatible)
- Rotación de refresh tokens (token rotation)
- Revocación en blacklist Redis

### 3. Autorización
- RBAC (Role-Based Access Control) granular
- Middleware de tenant isolation en cada request
- Validación de pertenencia al tenant antes de cualquier operación
- Principio de mínimo privilegio

### 4. Datos
- Contraseñas: Argon2id (más seguro que bcrypt)
- Datos sensibles en reposo: AES-256-GCM
- Imágenes/documentos: URLs firmadas con expiración (15 min)
- SQL injection: imposible con Prisma (queries parametrizadas)
- XSS: sanitización con DOMPurify + CSP estricto
- CSRF: tokens SameSite + double-submit cookie

### 5. Archivos / Uploads
- Validación de tipo MIME real (no solo extensión)
- Escaneo de malware con ClamAV
- Límite de tamaño por rol
- Almacenamiento fuera del webroot
- No ejecución de archivos subidos

### 6. Auditoría
- Log inmutable de todas las acciones (append-only)
- IP, user-agent, timestamp, acción, resultado
- Alertas automáticas por patrones sospechosos

---

## Flujo de Aprobación — Motor de Workflow

Cada empresa configura su propio flujo con N etapas:

```
Solicitud → Etapa 1 (Jefe Directo) → Etapa 2 (Finanzas) → Etapa 3 (Gerencia) → Aprobado/Rechazado
                                    ↓ rechazar
                              Devuelto al solicitante
```

Reglas configurables por empresa:
- Número de etapas (1 a 10)
- Rol aprobador por etapa
- Monto máximo por rol (ej: Jefe solo hasta $500k, Gerente hasta $5M)
- Tiempo límite por etapa (SLA con escalamiento automático)
- Aprobación paralela vs secuencial
- Delegación de aprobaciones

---

## Estructura de Directorios

```
expenseflow-saas/
├── backend/
│   ├── src/
│   │   ├── config/          ← env, database, redis, storage
│   │   ├── middleware/      ← auth, tenant, rate-limit, security headers
│   │   ├── modules/
│   │   │   ├── auth/        ← login, register, MFA, tokens
│   │   │   ├── tenants/     ← CRUD empresas, configuración
│   │   │   ├── users/       ← CRUD usuarios por tenant
│   │   │   ├── expenses/    ← solicitudes, uploads, estados
│   │   │   ├── workflows/   ← motor de flujos, etapas, reglas
│   │   │   └── erp/         ← integraciones externas
│   │   └── utils/           ← crypto, email, queue, logger
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── migrations/
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── app/             ← Next.js App Router
│   │   │   ├── (auth)/      ← login, register, MFA
│   │   │   ├── admin/       ← panel super admin
│   │   │   └── [tenant]/    ← portal por empresa
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── lib/             ← axios, auth helpers
│   │   └── store/           ← zustand stores
│   └── Dockerfile
├── nginx/
│   └── nginx.conf
├── docker-compose.yml
├── docker-compose.prod.yml
└── .env.example
```
