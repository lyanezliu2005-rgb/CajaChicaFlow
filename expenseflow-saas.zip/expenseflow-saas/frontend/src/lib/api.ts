// frontend/src/lib/api.ts
// Cliente Axios con interceptor de refresh automático y CSRF protection

import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'

export const apiClient = axios.create({
  baseURL: API_URL,
  withCredentials: true, // Necesario para enviar refresh token cookie
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// ─── INTERCEPTOR: añadir X-Tenant-ID automáticamente ─────────────────────────
apiClient.interceptors.request.use((config) => {
  // Extraer tenant del subdominio
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname
    const parts = hostname.split('.')
    const knownSubdomains = ['www', 'api', 'admin', 'app', 'localhost']
    if (parts.length >= 2 && !knownSubdomains.includes(parts[0])) {
      config.headers['X-Tenant-ID'] = parts[0]
    }
  }
  return config
})

// ─── INTERCEPTOR: refresh automático en 401 ────────────────────────────────── 
let isRefreshing = false
let failedQueue: Array<{
  resolve: (token: string) => void
  reject: (err: Error) => void
}> = []

const processQueue = (error: Error | null, token: string | null) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) reject(error)
    else resolve(token!)
  })
  failedQueue = []
}

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean; _skipAuthRefresh?: boolean }

    // No reintentar si ya se reintentó, o si es el endpoint de refresh/logout
    if (
      error.response?.status !== 401 ||
      originalRequest._retry ||
      originalRequest._skipAuthRefresh ||
      originalRequest.url?.includes('/auth/refresh') ||
      originalRequest.url?.includes('/auth/logout')
    ) {
      return Promise.reject(error)
    }

    if (isRefreshing) {
      // Esperar a que termine el refresh en curso
      return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject })
      }).then((token) => {
        originalRequest.headers['Authorization'] = `Bearer ${token}`
        return apiClient(originalRequest)
      })
    }

    originalRequest._retry = true
    isRefreshing = true

    try {
      const { data } = await apiClient.post('/api/v1/auth/refresh', {}, {
        withCredentials: true,
        _skipAuthRefresh: true,
      } as any)

      const newToken = data.accessToken
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${newToken}`

      // Actualizar store (importación dinámica para evitar circular dependency)
      const { useAuthStore } = await import('../store/auth.store')
      useAuthStore.getState().setAccessToken(newToken)

      processQueue(null, newToken)
      originalRequest.headers['Authorization'] = `Bearer ${newToken}`
      return apiClient(originalRequest)

    } catch (refreshError) {
      processQueue(refreshError as Error, null)

      // Redirigir al login
      const { useAuthStore } = await import('../store/auth.store')
      useAuthStore.getState().clearAuth()

      if (typeof window !== 'undefined') {
        window.location.href = '/auth/login?session=expired'
      }

      return Promise.reject(refreshError)
    } finally {
      isRefreshing = false
    }
  }
)

// ─── HELPERS ──────────────────────────────────────────────────────────────────

export const expenseApi = {
  list: (params?: any) => apiClient.get('/api/v1/t/expenses', { params }),
  get: (id: string) => apiClient.get(`/api/v1/t/expenses/${id}`),
  create: (data: any) => apiClient.post('/api/v1/t/expenses', data),
  approve: (id: string, data: any) => apiClient.post(`/api/v1/t/expenses/${id}/approve`, data),
  uploadFile: (id: string, formData: FormData) =>
    apiClient.post(`/api/v1/t/expenses/${id}/attachments`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getSignedUrl: (attachmentId: string) =>
    apiClient.get(`/api/v1/t/expenses/attachments/${attachmentId}/download`),
}

export const adminApi = {
  listTenants: (params?: any) => apiClient.get('/api/v1/admin/tenants', { params }),
  createTenant: (data: any) => apiClient.post('/api/v1/admin/tenants', data),
  updateTenant: (id: string, data: any) => apiClient.patch(`/api/v1/admin/tenants/${id}`, data),
  suspendTenant: (id: string, reason: string) =>
    apiClient.post(`/api/v1/admin/tenants/${id}/suspend`, { reason }),
  getStats: () => apiClient.get('/api/v1/admin/stats'),
}

export const workflowApi = {
  getTemplates: () => apiClient.get('/api/v1/t/workflows'),
  createTemplate: (data: any) => apiClient.post('/api/v1/t/workflows', data),
  updateTemplate: (id: string, data: any) => apiClient.put(`/api/v1/t/workflows/${id}`, data),
}

export const erpApi = {
  getConfigs: () => apiClient.get('/api/v1/t/erp/configs'),
  saveConfig: (data: any) => apiClient.post('/api/v1/t/erp/configs', data),
  testConnection: (type: string) => apiClient.post(`/api/v1/t/erp/test/${type}`),
  exportExpenses: (ids: string[]) => apiClient.post('/api/v1/t/erp/export', { expenseIds: ids }),
}
