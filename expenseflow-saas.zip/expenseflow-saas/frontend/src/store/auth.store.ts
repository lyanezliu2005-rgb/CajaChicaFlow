// frontend/src/store/auth.store.ts
// SEGURIDAD: Access token NUNCA en localStorage. Solo en memoria (JS).
// Refresh token: HttpOnly cookie (manejado por el servidor).

import { create } from 'zustand'
import { apiClient } from '../lib/api'

interface User {
  id: string
  email: string
  name: string
  roles: string[]
  type: 'super_admin' | 'tenant_user'
  tenantSlug?: string
}

interface AuthState {
  user: User | null
  accessToken: string | null  // Solo en memoria RAM
  isLoading: boolean
  isAuthenticated: boolean

  login: (email: string, password: string, mfaCode?: string) => Promise<void>
  logout: () => Promise<void>
  refreshToken: () => Promise<boolean>
  setAccessToken: (token: string) => void
  clearAuth: () => void
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  accessToken: null,
  isLoading: false,
  isAuthenticated: false,

  login: async (email, password, mfaCode) => {
    set({ isLoading: true })
    try {
      const endpoint = window.location.hostname.startsWith('admin.')
        ? '/api/v1/auth/admin/login'
        : '/api/v1/auth/login'

      const res = await apiClient.post(endpoint, {
        email,
        password,
        ...(mfaCode && { mfaCode }),
      })

      // Access token en memoria
      set({
        accessToken: res.data.accessToken,
        user: res.data.user,
        isAuthenticated: true,
        isLoading: false,
      })

      // Refresh token llega como HttpOnly cookie automáticamente
      // No necesitamos manejarlo manualmente

      // Configurar el interceptor de Axios con el nuevo token
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${res.data.accessToken}`

    } catch (err) {
      set({ isLoading: false })
      throw err
    }
  },

  logout: async () => {
    try {
      await apiClient.post('/api/v1/auth/logout')
    } catch { /* ignorar errores de logout */ }
    get().clearAuth()
  },

  refreshToken: async () => {
    try {
      // El refresh token se envía automáticamente como cookie HttpOnly
      const res = await apiClient.post('/api/v1/auth/refresh', {}, {
        withCredentials: true,
        _skipAuthRefresh: true, // evitar loop infinito
      } as any)

      set({
        accessToken: res.data.accessToken,
        user: res.data.user,
        isAuthenticated: true,
      })

      apiClient.defaults.headers.common['Authorization'] = `Bearer ${res.data.accessToken}`
      return true
    } catch {
      get().clearAuth()
      return false
    }
  },

  setAccessToken: (token) => {
    set({ accessToken: token })
    apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`
  },

  clearAuth: () => {
    set({ user: null, accessToken: null, isAuthenticated: false })
    delete apiClient.defaults.headers.common['Authorization']
  },
}))
